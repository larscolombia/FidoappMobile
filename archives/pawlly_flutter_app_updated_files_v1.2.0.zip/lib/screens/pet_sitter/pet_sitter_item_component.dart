import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly/components/cached_image_widget.dart';
import 'package:pawlly/generated/assets.dart';
import 'package:pawlly/main.dart';
import 'package:pawlly/utils/colors.dart';
import 'package:pawlly/utils/common_base.dart';

import 'employee_detail_screen.dart';
import 'pet_sitter_model.dart';

class PetSitterItemComponent extends StatelessWidget {
  final PetSitterItem petSitter;

  const PetSitterItemComponent({super.key, required this.petSitter});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: petSitter.id > 0
          ? () {
              Get.to(() => EmployeeDetailScreen(), arguments: petSitter.id);
            }
          : null,
      behavior: HitTestBehavior.translucent,
      child: Container(
        width: Get.width * 0.42,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.white,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CachedImageWidget(
              url: petSitter.profileImage,
              height: 80,
              width: 80,
              fit: BoxFit.cover,
              circle: true,
            ),
            16.height,
            Text(petSitter.fullName, textAlign: TextAlign.center, style: boldTextStyle(size: 12)),
            16.height,
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () {
                    if (petSitter.mobile.isEmpty) {
                      toast("${petSitter.fullName} ${locale.value.hasNotSharedTheir}");
                    } else {
                      launchCall(petSitter.mobile);
                    }
                  },
                  behavior: HitTestBehavior.translucent,
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: boxDecorationDefault(
                      color: lightPrimaryColor,
                      shape: BoxShape.circle,
                    ),
                    child: commonLeadingWid(imgPath: Assets.iconsCall, icon: Icons.mail_outlined, color: secondaryTextColor.withOpacity(0.7)),
                  ),
                ),
                16.width,
                GestureDetector(
                  onTap: () {
                    log('PETSITTER.EMAIL: ${petSitter.email}');
                    if (petSitter.email.isEmpty) {
                      toast("${petSitter.fullName} ${locale.value.hasNotSharedTheirEmail}");
                    } else {
                      launchMail(petSitter.email);
                    }
                  },
                  behavior: HitTestBehavior.translucent,
                  child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: boxDecorationDefault(
                        color: lightPrimaryColor,
                        shape: BoxShape.circle,
                      ),
                      child: commonLeadingWid(imgPath: Assets.iconsIcMail, icon: Icons.mail_outlined, color: secondaryTextColor.withOpacity(0.7))),
                ),
              ],
            ),
          ],
        ).paddingSymmetric(horizontal: 16, vertical: 16),
      ),
    );
  }
}
