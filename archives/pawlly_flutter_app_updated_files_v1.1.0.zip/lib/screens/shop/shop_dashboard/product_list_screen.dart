import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly/screens/shop/shop_dashboard/product_list_controller.dart';
import 'package:pawlly/screens/shop/shop_dashboard/shop_search_screen.dart';

import '../../../components/app_scaffold.dart';
import '../../../components/loader_widget.dart';
import '../../../components/search_widget.dart';
import '../../../main.dart';
import '../../../utils/empty_error_state_widget.dart';
import 'components/product_item_component.dart';
import 'model/product_list_response.dart';

class ProductListScreen extends StatelessWidget {
  final String? title;

  ProductListScreen({super.key, this.title});
  final ProductListController productListController = Get.put(ProductListController());

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      appBartitleText: title,
      isLoading: productListController.isLoading,
      body: Obx(
        () => SnapHelperWidget<List<ProductItemData>>(
          future: productListController.getFeatured.value,
          errorBuilder: (error) {
            return NoDataWidget(
              title: error,
              retryText: locale.value.reload,
              imageWidget: const ErrorStateWidget(),
              onRetry: () {
                productListController.page(1);
                productListController.isLoading(true);
                productListController.init();
              },
            ).paddingSymmetric(horizontal: 16);
          },
          loadingWidget: const LoaderWidget(),
          onSuccess: (productList) {
            if (productList.isEmpty) {
              return NoDataWidget(
                title: locale.value.noProductsFound,
                retryText: locale.value.reload,
                onRetry: () {
                  productListController.page(1);
                  productListController.isLoading(true);
                  productListController.init();
                },
              );
            }
            return AnimatedScrollView(
              padding: const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 30),
              onNextPage: () async {
                if (!productListController.isLastPage.value) {
                  productListController.page(productListController.page.value + 1);
                  productListController.isLoading(true);
                  productListController.init();
                  return await Future.delayed(const Duration(seconds: 2), () {
                    productListController.isLoading(false);
                  });
                }
              },
              onSwipeRefresh: () async {
                productListController.page(1);
                productListController.init();
                return await Future.delayed(const Duration(seconds: 2));
              },
              children: [
                SearchBarWidget(
                  productListController: ProductListController(),
                  onTap: () {
                    hideKeyboard(context);
                    Get.to(() => ShopSearchScreen());
                  },
                ),
                16.height,
                AnimatedWrap(
                  itemCount: productList.length,
                  spacing: 16,
                  runSpacing: 16,
                  itemBuilder: (context, index) {
                    return Obx(() => ProductItemComponents(productListData: productList[index]));
                  },
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
