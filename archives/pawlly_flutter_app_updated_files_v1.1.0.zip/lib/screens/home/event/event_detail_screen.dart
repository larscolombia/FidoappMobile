import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly/components/app_scaffold.dart';
import 'package:pawlly/main.dart';
import 'package:pawlly/utils/common_base.dart';

import '../../../components/cached_image_widget.dart';
import '../../../generated/assets.dart';
import '../../../google_calendar/calendar_event_service.dart';
import 'event_detail_controller.dart';
import '../../../utils/colors.dart';

class EventDetailScreen extends StatelessWidget {
  EventDetailScreen({super.key});

  final EventDetailController eventDetailController = Get.put(EventDetailController());

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
        appBartitleText: locale.value.eventDetail,
        body: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 120),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Hero(
                tag: "${eventDetailController.eventDetailFromArg.value.image}${eventDetailController.eventDetailFromArg.value.id}",
                child: CachedImageWidget(
                  url: eventDetailController.eventDetailFromArg.value.image,
                  width: Get.width,
                  fit: BoxFit.fitWidth,
                  height: 240,
                ),
              ),
              16.height,
              Hero(
                tag: eventDetailController.eventDetailFromArg.value.name,
                child: Text(
                  eventDetailController.eventDetailFromArg.value.name,
                  style: primaryTextStyle(size: 18, decoration: TextDecoration.none),
                ).paddingSymmetric(horizontal: 16),
              ),
              16.height,
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CachedImageWidget(
                    url: eventDetailController.eventDetailFromArg.value.organizerImage,
                    height: 25,
                    width: 25,
                    circle: true,
                    radius: 25,
                    fit: BoxFit.cover,
                  ),
                  8.width,
                  Text(eventDetailController.eventDetailFromArg.value.organizerName, style: secondaryTextStyle()),
                  const Spacer(),
                  commonLeadingWid(imgPath: Assets.navigationIcCalendarOutlined, icon: Icons.event, color: primaryColor),
                  8.width,
                  GestureDetector(
                      onTap: () {
                        showConfirmDialogCustom(
                          context,
                          primaryColor: primaryColor,
                          negativeText: locale.value.cancel,
                          positiveText: locale.value.yes,
                          onAccept: (_) {
                            eventDetailController.isLoading(true);
                            DateTime eventDateTime = eventDetailController.eventDetailFromArg.value.date.dateInyyyyMMddHHmmFormat;
                            String description = locale.value.petEvents;
                            String location = eventDetailController.eventDetailFromArg.value.location;
                            addToGoogleCalendar(
                                    title: "${eventDetailController.eventDetailFromArg.value.organizerName} - ${eventDetailController.eventDetailFromArg.value.name}",
                                    description: description,
                                    location: location,
                                    startTime: eventDateTime,
                                    endTime: eventDateTime.add(const Duration(hours: 1)))
                                .then((isSuccess) {
                              debugPrint('ISSUCCESS: $isSuccess');
                              if (isSuccess) {
                                Get.back();
                              }
                              eventDetailController.isLoading(false);
                            });
                          },
                          dialogType: DialogType.CONFIRMATION,
                          title: "${locale.value.doYouWantToAddEvent}?",
                        );
                      },
                      child: Text(eventDetailController.eventDetailFromArg.value.date.dateInyyyyMMddHHmmFormat.toString().dateInMMMMDyyyyFormat, style: secondaryTextStyle())),
                ],
              ).paddingSymmetric(horizontal: 16),
              16.height,
              commonDivider,
              if (eventDetailController.eventDetailFromArg.value.location.isNotEmpty) ...[
                16.height,
                GestureDetector(
                  onTap: () {
                    launchMap(eventDetailController.eventDetailFromArg.value.location);
                  },
                  child: Row(
                    children: [
                      commonLeadingWid(imgPath: Assets.iconsIcMyAddress, icon: Icons.location_on_outlined, color: secondaryColor),
                      8.width,
                      Text(eventDetailController.eventDetailFromArg.value.location, style: secondaryTextStyle()),
                    ],
                  ).paddingSymmetric(horizontal: 16),
                )
              ],
              16.height,
              Text(parseHtmlString(eventDetailController.eventDetailFromArg.value.description), style: secondaryTextStyle()).paddingSymmetric(horizontal: 16),
              32.height,
            ],
          ),
        ));
  }
}
