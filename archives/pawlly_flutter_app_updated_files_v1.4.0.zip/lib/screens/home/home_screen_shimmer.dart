import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly/screens/home/components/choose_service_components_shimmer.dart';
import 'package:pawlly/screens/home/components/featured_product_home_component_shimmer.dart';
import 'package:pawlly/screens/home/components/greetings_component_shimmer.dart';
import 'package:pawlly/screens/home/components/sliders_component_shimmer.dart';
import 'package:pawlly/screens/home/components/upcoming_appointment_components_shimmer.dart';
import 'package:pawlly/screens/pet_sitter/pet_sitter_home_components_shimmer.dart';

class HomeScreenShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AnimatedScrollView(
      listAnimationType: ListAnimationType.None,
      padding: const EdgeInsets.only(bottom: 16),
      children: [
        32.height,
        const GreetingsComponentShimmer(),
        const SlidersComponentShimmer(),
        16.height,
        const ChooseServiceComponentsShimmer(),
        const UpcomingAppointmentComponentShimmer(),
        const ChoosePetSitterHomeComponentsShimmer(),
        16.height,
        const FeaturedProductHomeComponentShimmer()
      ],
    );
  }
}
