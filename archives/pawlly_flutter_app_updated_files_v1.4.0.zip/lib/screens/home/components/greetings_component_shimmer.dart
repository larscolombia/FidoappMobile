import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly/components/circle_widget.dart';
import 'package:pawlly/components/shimmer_widget.dart';
import 'package:pawlly/utils/colors.dart';

class GreetingsComponentShimmer extends StatelessWidget {
  const GreetingsComponentShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          children: [
            ShimmerWidget(padding: const EdgeInsets.symmetric(horizontal: 108, vertical: 8)),
            4.height,
            ShimmerWidget(padding: const EdgeInsets.symmetric(horizontal: 108, vertical: 8)),
          ],
        ),
        ShimmerWidget(
          baseColor: shimmerLightBaseColor,
          child: CircleWidget(height: 36, width: 36),
        )
      ],
    ).paddingSymmetric(horizontal: 16, vertical: 16);
  }
}
