import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly/screens/booking_module/booking_list/booking_card_shimmer.dart';

class BookingsScreenShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AnimatedListView(
      shrinkWrap: true,
      itemCount: 10,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemBuilder: (BuildContext, int) {
        return BookingCardShimmer(isFromHome: true);
      },
    );
  }
}
