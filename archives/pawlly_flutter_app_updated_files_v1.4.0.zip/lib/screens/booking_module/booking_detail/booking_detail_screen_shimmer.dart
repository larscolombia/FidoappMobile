import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly/components/screen_shimmer.dart';
import 'package:pawlly/components/shimmer_widget.dart';
import 'package:pawlly/utils/colors.dart';

class BookingDetailScreenShimmer extends StatelessWidget {
  const BookingDetailScreenShimmer({Key? key}) : super(key: key);

  Widget customerInformationComponentShimmer(BuildContext ctx) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShimmerWidget(padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 8)),
        16.height,
        Stack(
          children: [
            ShimmerWidget(
              baseColor: shimmerLightBaseColor,
              child: Container(
                height: 130,
                width: Get.width - 16,
                padding: EdgeInsets.all(16),
                decoration: boxDecorationDefault(),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                16.height,
                ...List.generate(
                  5,
                  (index) => Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ShimmerWidget(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      ).expand(flex: 3),
                      Spacer(),
                      ShimmerWidget(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      ).expand(flex: 3)
                    ],
                  ).paddingSymmetric(horizontal: 12, vertical: 2),
                ),
              ],
            ),
          ],
        )
      ],
    ).paddingSymmetric(horizontal: 16);
  }

  @override
  Widget build(BuildContext context) {
    return ScreenShimmer(
      itemCount: 5,
      shimmerComponent: customerInformationComponentShimmer(context),
    );
  }
}
