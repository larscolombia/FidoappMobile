import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly/components/shimmer_widget.dart';
import 'package:pawlly/screens/home/components/featured_product_item_component_shimmer.dart';
import 'package:pawlly/utils/app_common.dart';
import 'package:pawlly/utils/colors.dart';

class DashboardFeaturedComponentsShimmer extends StatelessWidget {
  const DashboardFeaturedComponentsShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(bottom: 16),
      width: Get.width,
      decoration: BoxDecoration(color: isDarkMode.value ? whiteColor.withOpacity(0.1) : lightPrimaryColor2),
      child: Wrap(
        direction: Axis.vertical,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ShimmerWidget(padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 8)),
              ShimmerWidget(padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 8)),
            ],
          ).paddingOnly(left: 16, right: 16),
          24.height,
          HorizontalList(
            runSpacing: 16,
            spacing: 16,
            wrapAlignment: WrapAlignment.start,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: 4,
            itemBuilder: (context, index) {
              return const FeaturedProductItemComponentShimmer();
            },
          )
        ],
      ).paddingSymmetric(vertical: 16),
    );
  }
}
