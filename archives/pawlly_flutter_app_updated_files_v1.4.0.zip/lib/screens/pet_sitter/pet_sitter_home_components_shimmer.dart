import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:pawlly/components/shimmer_widget.dart';
import 'package:pawlly/screens/pet_sitter/pet_sitter_item_component_shimmer.dart';

class ChoosePetSitterHomeComponentsShimmer extends StatelessWidget {
  const ChoosePetSitterHomeComponentsShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ShimmerWidget(padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 8)),
            ShimmerWidget(padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 8)),
          ],
        ).paddingOnly(left: 16, right: 16),
        24.height,
        HorizontalList(
          runSpacing: 16,
          spacing: 16,
          wrapAlignment: WrapAlignment.start,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: 8,
          itemBuilder: (context, index) {
            return PetSitterItemComponentShimmer();
          },
        )
      ],
    );
  }
}
